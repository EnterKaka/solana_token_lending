import { LendingDashboard } from '../components';

export default function Lending(): JSX.Element {
  return (
    <LendingDashboard />
  );
}
