export { default as PaymentModal } from './view';

export interface ParentElementProps {
  children: React.ReactNode;
}
