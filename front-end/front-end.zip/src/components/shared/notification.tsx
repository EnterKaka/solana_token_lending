export default function Notification(): React.ReactElement {
  return <div></div>;
}
