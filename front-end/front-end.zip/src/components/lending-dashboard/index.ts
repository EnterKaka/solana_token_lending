export { default as LendingDashboard } from './view';

