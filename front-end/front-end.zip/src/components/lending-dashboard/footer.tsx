
export default function Footer() {
  return <div className='pr-8 text-md font-thin text-gray-500  text-opacity-30'>dashboard footer</div>;
}
