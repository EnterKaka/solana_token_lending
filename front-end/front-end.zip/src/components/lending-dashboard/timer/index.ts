export { default as Timer } from './view';
