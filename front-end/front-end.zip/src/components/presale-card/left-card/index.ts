export { default as LeftCard } from './view';

export enum WalletStatus {
  Connected,
  NotConnected,
  NotWhiteListed,
}
