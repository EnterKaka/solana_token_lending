export { default as RightCard } from './view';
