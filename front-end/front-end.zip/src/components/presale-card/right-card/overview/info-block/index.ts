export { default as InfoBlock } from './view';
