export { default as Logo } from './logo';
export { default as ColorWave } from './color-wave';

export interface SvgProps {
  className?: string;
}
